# sequence-generator
Uncommment  
- line 7 #include<matplotlib.h>  
- line 226 //matplotlibcpp::plot(arr);  
- line 227 //matplotlibcpp::show();  
to plot sequences  
Dependencies:  
            - matplotlibcpp - https://github.com/lava/matplotlib-cpp
